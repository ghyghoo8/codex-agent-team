# Codex Agent Team：本地开发交接包

> 整理日期：2026-09-18。状态：Handoff Draft v0.1，供核对和评审，不是全量实施授权。

## 从哪里开始

先读 [主交接文档](docs/local-development-handoff.md)。第 19 节提供本地接手顺序，第 21 节是可直接复制给本地 Codex 的只读核对提示词。

```text
docs/local-development-handoff.md                           主交接文档（22 节）
reference/codex-runtime-control-plane-discussion-archive.md  原讨论归档，字节内容不修改
reference/source/codex-team-control-plane-implementation-guide.md
                                                           原 Proposed v0.5，字节内容不修改
evidence/source-manifest.json                              来源状态与本包文件 SHA-256
```

建议将主文档放入目标仓库 `docs/local-development-handoff.md`。其余文件供离线追溯；先检查仓库已有文件，避免覆盖既有方案和用户改动。

## 本包不代表什么

不代表目标仓库已经提交或推送；不代表已确定云端部署、采用 Todos 或接入 PowerContext；不代表旧 Hook／动态调度草案重新生效。没有执行宿主探针、安装插件、启用服务或修改业务代码。

原 v0.5、归档和本轮候选设计分开保留。主文档完整复述本地接手所需的关键边界，但不是旧文件的替代授权。

SHA-256 用于验证本包内容一致性，不证明原材料中的事实、授权或外部仓库版本正确。外部文档未统一固定提交，正式实施前需要本地核验。
