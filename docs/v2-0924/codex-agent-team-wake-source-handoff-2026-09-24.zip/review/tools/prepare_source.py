"""Verify and safely unpack the user-supplied Wake snapshot; execute no repo code."""
from pathlib import Path, PurePosixPath
import hashlib, stat, zipfile
ROOT = Path(__file__).resolve().parents[2]
ZIP = ROOT / "Wake-main.zip"
OUT = ROOT / "review" / "source"
EXPECTED = "638d9396eb5f24229ea7f6e031071369534fd89557a2c4e16963e1455c19a3fe"
if hashlib.sha256(ZIP.read_bytes()).hexdigest() != EXPECTED:
    raise SystemExit("Archive SHA-256 mismatch; nothing extracted.")
if OUT.is_symlink():
    raise SystemExit("Refusing symlink destination.")
with zipfile.ZipFile(ZIP) as z:
    members = z.infolist()
    if len(members)>1000 or sum(i.file_size for i in members)>20*1024*1024:
        raise SystemExit("Unexpected archive size.")
    seen=set()
    for i in members:
        p=PurePosixPath(i.filename)
        if p.is_absolute() or ".." in p.parts or "\\" in i.filename or p.parts[0] != "Wake-main":
            raise SystemExit("Unsafe archive path.")
        if stat.S_ISLNK(i.external_attr >> 16):
            raise SystemExit("Symlink member refused.")
        if not i.is_dir():
            if str(p) in seen: raise SystemExit("Duplicate member.")
            seen.add(str(p))
    OUT.mkdir(parents=True, exist_ok=True)
    for i in members:
        target=OUT/i.filename
        for parent in [target,*target.parents]:
            if parent == OUT.parent: break
            if parent.is_symlink():raise SystemExit("Symlink in destination path.")
        if i.is_dir(): target.mkdir(parents=True,exist_ok=True); continue
        data=z.read(i)
        if target.exists():
            if not target.is_file() or target.read_bytes()!=data:
                raise SystemExit("Existing source differs; refusing overwrite: "+i.filename)
            continue
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open("xb") as f: f.write(data)
print("Verified source available at", OUT / "Wake-main")
