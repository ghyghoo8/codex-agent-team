
CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS sessions (
  key            TEXT PRIMARY KEY,
  agent_id       TEXT NOT NULL,
  native_id      TEXT NOT NULL,
  title          TEXT NOT NULL DEFAULT '',
  project_path   TEXT NOT NULL DEFAULT '',
  project_name   TEXT NOT NULL DEFAULT '',
  git_branch     TEXT,
  created_at     INTEGER DEFAULT 0,
  updated_at     INTEGER DEFAULT 0,
  message_count  INTEGER DEFAULT 0,
  tokens_used    INTEGER,
  model          TEXT,
  source         TEXT,
  archived       INTEGER DEFAULT 0,
  file_path      TEXT NOT NULL UNIQUE,
  file_size      INTEGER DEFAULT 0,
  file_mtime     INTEGER DEFAULT 0,
  unknown_lines  INTEGER DEFAULT 0,
  parent_key     TEXT NOT NULL DEFAULT '',
  host           TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sessions_updated ON sessions(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_agent   ON sessions(agent_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_path, updated_at DESC);

CREATE TABLE IF NOT EXISTS messages (
  id           INTEGER PRIMARY KEY,
  session_key  TEXT NOT NULL,
  sidechain_id TEXT,
  seq          INTEGER NOT NULL,
  role         TEXT, ts INTEGER,
  text         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_key);

CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
  text,
  content='messages', content_rowid='id',
  tokenize="trigram case_sensitive 0"
);

CREATE TABLE IF NOT EXISTS user_data (
  session_key TEXT PRIMARY KEY,
  favorite    INTEGER DEFAULT 0,
  pinned      INTEGER DEFAULT 0,
  updated_at  INTEGER
);

CREATE TABLE IF NOT EXISTS tombstones (
  file_path  TEXT PRIMARY KEY,
  key        TEXT,
  deleted_at INTEGER
);

CREATE TABLE IF NOT EXISTS custom_roots (
  agent    TEXT NOT NULL,
  path     TEXT NOT NULL,
  added_at INTEGER,
  PRIMARY KEY (agent, path)
);

CREATE TABLE IF NOT EXISTS removed_defaults (
  agent      TEXT PRIMARY KEY,
  removed_at INTEGER
);

CREATE TABLE IF NOT EXISTS removed_default_roots (
  agent      TEXT NOT NULL,
  path       TEXT NOT NULL,
  removed_at INTEGER,
  PRIMARY KEY (agent, path)
);

-- 应用级 UI 偏好。与 schema_meta 同形但语义不同:schema_meta 是索引
-- 自身的迁移状态,迁移代码可随意增删;prefs 是用户数据(user_data 同类,
-- 只是不挂在会话上),勿合并两表
CREATE TABLE IF NOT EXISTS prefs (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS disabled_locations (
  agent       TEXT NOT NULL,
  path        TEXT NOT NULL,
  disabled_at INTEGER,
  PRIMARY KEY (agent, path)
);

CREATE TABLE IF NOT EXISTS remote_hosts (
  name            TEXT PRIMARY KEY,
  enabled         INTEGER DEFAULT 1,
  added_at        INTEGER,
  last_sync_at    INTEGER,
  last_sync_error TEXT
);

-- 标题的全文索引。独立一张表而不挂在 messages 上:标题不是转录消息、没有 seq
-- 可对,塞成假消息会破坏 seq 契约。key 不索引、只用来回查/删除
CREATE VIRTUAL TABLE IF NOT EXISTS titles_fts USING fts5(
  key UNINDEXED,
  title,
  tokenize="trigram case_sensitive 0"
);

-- agent 自己写下的记忆(Claude Code auto-memory、Codex memories)的只读镜像:
-- 扫描收尾按 (agent, host) 整组替换(2026-09-17)。正文一并入库(小 Markdown),
-- 搜索走 memories_fts(rowid = memories.id,删改按 rowid 定位——FTS 表里
-- UNINDEXED 列的 WHERE 是整表扫描,正文列在里面扫不起);阅读时文件型先读
-- 磁盘、读不到再用这份。project_path 多半为空,读时按 session_key 连 sessions 解析
CREATE TABLE IF NOT EXISTS memories (
  id           INTEGER PRIMARY KEY,
  key          TEXT NOT NULL UNIQUE,
  agent_id     TEXT NOT NULL,
  host         TEXT NOT NULL DEFAULT '',
  scope        TEXT NOT NULL,
  project_path TEXT NOT NULL DEFAULT '',
  project_name TEXT NOT NULL DEFAULT '',
  session_key  TEXT NOT NULL DEFAULT '',
  path         TEXT NOT NULL,
  title        TEXT NOT NULL DEFAULT '',
  updated_at   INTEGER DEFAULT 0,
  size_bytes   INTEGER DEFAULT 0,
  source       TEXT NOT NULL DEFAULT '',
  body         TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_memories_group ON memories(agent_id, host);
CREATE TABLE IF NOT EXISTS memory_sources_custom (
  agent    TEXT NOT NULL,
  path     TEXT NOT NULL,
  added_at INTEGER NOT NULL,
  PRIMARY KEY (agent, path)
);
CREATE TABLE IF NOT EXISTS memory_sources_disabled (
  agent       TEXT NOT NULL,
  source      TEXT NOT NULL,
  disabled_at INTEGER NOT NULL,
  PRIMARY KEY (agent, source)
);
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
  title,
  body,
  tokenize="trigram case_sensitive 0"
);

-- agent 查 Wake 的每一次调用(解析时从工具调用里认出,2026-09-17)。与 messages
-- 同一事务写、同 key 删;channel = mcp | cli,tool = MCP 工具名或命令行二进制名,
-- ts = 所在消息的时间(缺则 NULL,归窗时退回会话 updated_at)。老库首开由
-- FTS_FORMAT 换代的全量重解析回填
CREATE TABLE IF NOT EXISTS wake_lookups (
  session_key TEXT NOT NULL,
  seq         INTEGER NOT NULL,
  ts          INTEGER,
  channel     TEXT NOT NULL,
  tool        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wake_lookups_session ON wake_lookups(session_key);
