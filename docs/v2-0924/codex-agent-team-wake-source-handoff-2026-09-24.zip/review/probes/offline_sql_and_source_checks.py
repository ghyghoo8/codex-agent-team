"""Narrow offline checks for the uploaded Wake snapshot.
Runs extracted original SQL in Python's SQLite, and explicitly labelled source assertions.
Does NOT compile/run Rust, exercise the MCP transport, access a user's Codex files, or test macOS.
"""
from pathlib import Path
import hashlib, io, json, re, sqlite3, sys, tempfile, unittest, platform
BASE=Path(__file__).resolve().parents[1]
SRC=BASE/'source'/'Wake-main'
DB_TEXT=(SRC/'crates/wake-core/src/db.rs').read_text()
DDL=re.search(r'const DDL: &str = r#"(.*?)"#;', DB_TEXT,re.S).group(1)
UP_TEXT=DB_TEXT[DB_TEXT.index('fn upsert_session('):DB_TEXT.index('fn escape_like(')]
UPSERT=re.search(r'"(INSERT INTO sessions\(key,.*?)",\s*params!\[', UP_TEXT,re.S).group(1)
# There are no Rust escape sequences in this SQL string. Fail rather than guessing.
assert '\\\\' not in UPSERT
(BASE/'probes'/'extracted-wake-schema.sql').write_text(DDL)
(BASE/'probes'/'extracted-wake-upsert.sql').write_text(UPSERT)

def connection():
    c=sqlite3.connect(':memory:'); c.executescript(DDL); return c

def session(c,key='codex:s1',updated=1000,path='/synthetic/s1.jsonl'):
    args=(key,'codex',key.split(':')[-1],'synthetic','/synthetic/project','project',None,
          100,updated,1,None,None,None,0,path,100,1000,'')
    c.execute(UPSERT,args)

def message(c,mid,text,key='codex:s1',seq=1):
    c.execute('INSERT INTO messages(id,session_key,seq,role,ts,text) VALUES(?,?,?,?,?,?)',
              (mid,key,seq,'user',100,text))
    c.execute('INSERT INTO messages_fts(rowid,text) VALUES(?,?)',(mid,text))

def match_literal(q):
    # Re-expression of db.rs:3143-3147 in Python, NOT original Rust execution.
    return ' AND '.join('"'+term.replace('"','""')+'"' for term in q.split())

def like_pattern(q):
    # Re-expression of db.rs:3125-3128.
    return '%'+q.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'

class OriginalSqlChecks(unittest.TestCase):
    def setUp(self): self.c=connection(); session(self.c)
    def tearDown(self): self.c.close()
    def hits(self,q):
        return self.c.execute('SELECT rowid FROM messages_fts WHERE messages_fts MATCH ?',
                              (match_literal(q),)).fetchall()
    def test_01_source_ddl_creates_trigram_index(self):
        sql=self.c.execute("SELECT sql FROM sqlite_master WHERE name='messages_fts'").fetchone()[0]
        self.assertIn('trigram case_sensitive 0',sql)
    def test_02_three_codepoint_chinese_match(self):
        message(self.c,1,'二维码扫描'); self.assertEqual(self.hits('二维码'),[(1,)])
    def test_03_two_codepoint_fts_has_no_hit(self):
        message(self.c,1,'权限控制'); self.assertEqual(self.hits('权限'),[])
    def test_04_two_codepoint_like_fallback(self):
        message(self.c,1,'权限控制')
        self.assertEqual(self.c.execute("SELECT id FROM messages WHERE text LIKE ? ESCAPE '\\'",
                                       (like_pattern('权限'),)).fetchall(),[(1,)])
    def test_05_code_substring_match(self):
        message(self.c,1,'const x = useEffect(() => work())'); self.assertEqual(self.hits('useEffect('),[(1,)])
    def test_06_quoted_input_is_literal(self):
        message(self.c,1,'the error says "failure" now'); self.assertEqual(self.hits('"failure"'),[(1,)])
    def test_07_like_wildcard_is_literal(self):
        message(self.c,1,'literal_100%'); message(self.c,2,'literalX1000')
        rows=self.c.execute("SELECT id FROM messages WHERE text LIKE ? ESCAPE '\\'",(like_pattern('_100%'),)).fetchall()
        self.assertEqual(rows,[(1,)])
    def test_08_terms_are_and(self):
        message(self.c,1,'alpha bravo'); message(self.c,2,'alpha charlie')
        self.assertEqual(self.hits('alpha bravo'),[(1,)])
    def test_09_original_upsert_unknown_diagnostics_zero(self):
        self.assertEqual(self.c.execute('SELECT unknown_lines FROM sessions').fetchone()[0],0)
    def test_10_original_upsert_does_not_update_unknown_diagnostics(self):
        self.c.execute('UPDATE sessions SET unknown_lines=7'); session(self.c,updated=2000)
        self.assertEqual(self.c.execute('SELECT unknown_lines FROM sessions').fetchone()[0],7)
    def test_11_latest_activity_is_not_a_scan_clock(self):
        a=self.c.execute('SELECT MAX(updated_at) FROM sessions').fetchone()[0]
        self.c.execute("INSERT INTO schema_meta VALUES('synthetic_last_scan','999999')")
        self.assertEqual(self.c.execute('SELECT MAX(updated_at) FROM sessions').fetchone()[0],a)
    def test_12_external_content_requires_explicit_fts_sync(self):
        message(self.c,1,'alpha bravo'); self.c.execute("UPDATE messages SET text='charlie delta' WHERE id=1")
        # Same external-content FTS5 schema: content UPDATE alone doesn't rebuild the index.
        self.assertEqual(self.hits('alpha'),[(1,)]); self.assertEqual(self.hits('charlie'),[])
    def test_13_messages_and_fts_transaction_can_rollback(self):
        self.c.commit(); self.c.execute('BEGIN'); message(self.c,1,'transaction marker'); self.c.rollback()
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],0)
        self.assertEqual(self.hits('transaction'),[])
    def test_14_readonly_connection_rejects_business_write(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'synthetic.db'; w=sqlite3.connect(p); w.executescript(DDL); w.close()
            r=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True)
            try:
                with self.assertRaises(sqlite3.OperationalError):r.execute("INSERT INTO prefs VALUES('x','y')")
            finally:r.close()

class StaticSourceChecks(unittest.TestCase):
    def text(self,path):return (SRC/path).read_text()
    def test_15_index_derivation_has_no_tool_output_field(self):
        s=self.text('crates/wake-core/src/adapters/mod.rs'); s=s[s.index('fn units_from_messages('):s.index('fn wake_lookups_from_messages(')]
        self.assertIn('tc.input_preview',s); self.assertNotIn('tc.output',s)
    def test_16_cli_index_and_refresh_exist(self):
        s=self.text('crates/wake-core/src/bin/wake_cli.rs')
        self.assertIn('Action::Index =>',s); self.assertIn('Action::Refresh =>',s)
    def test_17_fixture_contains_unknown_event(self):
        p='crates/wake-core/tests/fixtures/codex/sessions/2026/08/02/rollout-2026-08-02T09-15-00-22222222-aaaa-bbbb-cccc-000000000002.jsonl'
        types=[json.loads(l)['type'] for l in self.text(p).splitlines()]
        self.assertEqual(types.count('mystery_row'),1)
    def test_18_tool_result_branch_does_not_derive_error_status(self):
        s=self.text('crates/wake-core/src/adapters/codex.rs')
        b=s[s.index('"function_call_output" | "custom_tool_call_output" =>'):s.index('// 与下面 event_msg')]
        self.assertIn('.output = Some',b); self.assertNotIn('is_error',b)
    def test_19_scope_parameter_optional_and_get_by_key(self):
        s=self.text('crates/wake-core/src/mcp/tools.rs')
        self.assertIn('return Ok(ProjectScope::All)',s)
        g=s[s.index('fn get_session('):s.index('#[cfg(test)]')]
        self.assertNotIn('project_scope!',g); self.assertIn('find_session(ctx.store, &key)',g)
    def test_20_source_identity_hash_matches_upload(self):
        self.assertEqual(hashlib.sha256((BASE.parent/'Wake-main.zip').read_bytes()).hexdigest(),
                         '638d9396eb5f24229ea7f6e031071369534fd89557a2c4e16963e1455c19a3fe')

class RecordingResult(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[]
    def addSuccess(self,test):
        super().addSuccess(test);self.rows.append({'id':test.id(),'type':'sql' if 'OriginalSql' in test.id() else 'static','result':'PASS'})
    def addFailure(self,test,err):
        super().addFailure(test,err);self.rows.append({'id':test.id(),'result':'FAIL'})
    def addError(self,test,err):
        super().addError(test,err);self.rows.append({'id':test.id(),'result':'ERROR'})

if __name__=='__main__':
    stream=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordingResult).run(suite)
    log=stream.getvalue();print(log)
    (BASE/'probes'/'results.txt').write_text(log)
    metadata={'python':sys.version,'sqlite':sqlite3.sqlite_version,'platform':platform.platform(),
              'source_sha256':hashlib.sha256((BASE.parent/'Wake-main.zip').read_bytes()).hexdigest(),
              'rust_tests':'NOT_RUN: rustc/cargo not installed; no dependencies installed',
              'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'checks':result.rows,
              'limits':'Original SQL run through Python SQLite; quoting helpers re-expressed in Python. Static assertions are not runtime tests. No Wake binary, parser, transport, GUI or user environment was executed.'}
    (BASE/'probes'/'results.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
    sys.exit(not result.wasSuccessful())
