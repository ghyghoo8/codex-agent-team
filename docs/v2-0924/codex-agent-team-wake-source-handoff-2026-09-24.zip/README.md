# Codex Agent Team：Wake 源码补强交接包

日期：2026-09-24。此包供本地评审与开发准备；不代表用户目标仓库已修改或所有候选能力已获准实施。

## 阅读顺序

1. `codex-agent-team-integrated-plan.md`：整合任务、角色、能力、历史证据与恢复；技术栈建议见 §13。
2. `wake-source-review.md`：本次实际源码发现、边界与离线验证。
3. `wake-source-evidence.md`：WK01–WK18 的选定原始行号片段。
4. `reference/`：原能力 v0.3、总体交接、原 v0.5 和可用归档，均保持原字节。

主方案建议入库 `docs/integrated-implementation-plan.md`；源码报告建议 `docs/reviews/wake-source-review.md`。
单独移动文件时需相应调整相对链接；本交接包根目录的链接按包结构有效。不要直接覆盖既有活动文档而不检查差异。

## 本轮真正的增量

| 原讨论或潜在误解 | 源码后的处理 |
|---|---|
| 必须 GUI 常驻才能更新历史索引 | 上传快照已有 CLI index/refresh；索引写入仍是独立效果 |
| 全文搜索可以找出所有测试输出 | 索引不包含工具 output；明确检索覆盖与有界原始读取 |
| session+seq 就是精确历史证据 | 解析会重组和截断；新增快照+原始 span+parser revision |
| unknown_lines=0 可以证明无解析问题 | 源码传播链存在缺口，原 SQL 验证确认写入行为 |
| 只读 MCP 自带角色和项目隔离 | 原 project 参数是便利过滤；任务 ACL 需所有读取路径强制 |
| 用户标记与索引分开，重建就无损 | 正常重建与打开失败重建不同；正式业务证据不能放在可清空索引权威 |
| Wake 恢复只有 CLI | 也有 macOS 深链；OS open 成功不代表运行已恢复或接管 |

## 源码身份与限制

原包 `Wake-main.zip`，ZIP 注释 `269c50b466b023a0f38cc14e34105ab27b983dd2`，SHA-256
`638d9396eb5f24229ea7f6e031071369534fd89557a2c4e16963e1455c19a3fe`。
215 个原文件复核无改动；包不含 .git，未独立认证远端 HEAD。

实际验证是 **14 项提取原 SQL 的行为检查 + 6 项静态/样例断言**，不是原 Rust suite。
环境：Python 3.13.5、SQLite 3.46.1、Linux。未安装 Rust/依赖，未调用 Wake 二进制、真实 MCP、macOS 或用户 Codex。
`review/reads.jsonl` 是请求读取的窗口日志，并不等于全仓每行审计通过。

## 重现有限验证

在本交接包目录中，使用已有 Python 3；不需要安装任何包：

```bash
python review/tools/prepare_source.py
python review/probes/offline_sql_and_source_checks.py
```

第一个脚本核对 ZIP 摘要及安全路径，将上传源码解压到 `review/source/Wake-main/`，不执行其中脚本。
第二个脚本使用合成数据及临时 SQLite，不读取真实主目录，不启动模型；它会重写 `review/probes/results.*` 和提取 SQL，复测前可保留原结果副本。
本轮原结果另存为 `review/probes/results.original.*`。

需要测真实 Rust、GUI 或用户会话时，应先明确安装、测试目录、数据范围与副作用，不能将此脚本的通过替代对应验证。

## 许可与复用

Wake 原源码和摘录适用随包 `WAKE-LICENSE.txt` 的 MIT 许可与原版权说明。引用或复用代码时保留许可；依赖许可另外核对。
整合方案不要求部署 Wake、SkillBox、PowerContext 或 Todos；CodexBoard 仍排除，旧动态调度/Hook 仍归档。

`SHA256SUMS.txt` 仅用于文件完整性校验，不是作者身份签名或安全认证。
